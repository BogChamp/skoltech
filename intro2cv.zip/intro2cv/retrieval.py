import cv2
import numpy as np
from sklearn.cluster import DBSCAN, OPTICS
from sklearn.cluster import KMeans


# matches we have to get to identify as match on image
MIN_MATCH_COUNT = 5

# supposed to be 1
FLANN_INDEX_KDTREE = 1

# threshold
threshold = 0.9


#------------------------------------------------------------#
def close(img, points, h, w):
    """
    checks if this is rectangle
    """
    x_array = [points[i] for i in range(1, 8, 2)]
    x_min, x_max = min(x_array), max(x_array)

    y_array = [points[j] for j in range(0, 7, 2)]
    y_min, y_max = min(y_array), max(y_array)

    img2 = img[x_min:x_max, y_min:y_max]
    h_img2, w_img2 = img2.shape
    return np.isclose(h_img2 / h, w_img2 / w, 0.23)
#------------------------------------------------------------#


#------------------------------------------------------------#
def find_and_polly(img, key_points_query, description_query, query, sift, flann):
    """
    this function takes an image and query then uses sift to find key points
    on img and query, then uses fillPoly to delete already found area
    and gives coordinates of cropped area
    can be done recursively with abusing of res (boolType)
    """
    # finding key points and descriptors on img
    key_points_img, descriptors_img = sift.detectAndCompute(img, None)

    # finding matches with knn on img with desc on query    
    matches = flann.knnMatch(description_query, descriptors_img, k=2)

    # creating a list & add into it if distance satisfies conditions
    dist = []
    for i, (m, n) in enumerate(matches):
        if m.distance < threshold * n.distance:
            dist.append(m)

    # list of distances
    dst_pt = [key_points_img[m.trainIdx].pt for m in dist]

    # labels via DBSCAN fitted on distances
    labels = DBSCAN(eps=100, min_samples = 3).fit_predict(dst_pt)
    #labels = OPTICS(max_eps=100).fit_predict(dst_pt)
    
    # let's create a dict with unique labels
    uniq = {}   
    for pos, a in enumerate(labels):
        if not (a in uniq):
            uniq[a] = 1
        else:
            uniq[a] +=1

    # max element
    max_el = max(uniq, key=uniq.get)

    # creating array of DMatch
    d_match_array = []
    for n, x in enumerate(labels): 
        if x == max_el:
            d_match_array.append(dist[n])

    # check if less than our min_match we return just img,
    # else we get location of matched key points in both images
    # use transformation matrix to transform the corners of query
    # to corresponding points in img
    if len(d_match_array) > MIN_MATCH_COUNT:
        src_pts = np.float32([key_points_query[m.queryIdx].pt for m in d_match_array]).reshape(-1, 1, 2)
        dst_pts = np.float32([key_points_img[m.trainIdx].pt for m in d_match_array]).reshape(-1, 1, 2)
        
        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
        matched_mask = mask.ravel().tolist()
        
        h, w = query.shape[0], query.shape[1]
        pts = np.float32([[0, 0], [0, h-1], [w-1, h-1], [w-1, 0]]).reshape(-1, 1, 2)
        dst = cv2.perspectiveTransform(pts, M)
        
        pts_transformed = np.int32(dst).reshape(8).tolist()
        close(img, pts_transformed, h, w)

        if not close(img, pts_transformed, h, w):
            return [False, img, [-1, -1, -1, -1]]

        img2 = cv2.fillPoly(img, [np.int32(dst)], 255)    # fillPoly to fill the already found area
        bbox = pts_transformed[:2] + pts_transformed[4:6]   

        return [True, img2, bbox]
    else:
        return [False, img, [-1, -1, -1, -1]]
#----------------------------------------------------------------------------#


#------------------------------------------------------------#
def predict_image(img: np.ndarray, query: np.ndarray) -> list: 
    # convert to gray
    img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    query = cv2.cvtColor(query, cv2.COLOR_RGB2GRAY)

    # creating a SIFT detector
    sift = cv2.SIFT_create()

    # finding key points and descriptors on query
    key_points_query, description_query = sift.detectAndCompute(query, None)

    # index_params & search_params
    
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=40)

    # flann matcher
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    
    # recursively use find_and_polly to find all matches on image and crop them until we don't have matches
    img_true, new_img, bbox = find_and_polly(img, key_points_query, description_query, query, sift, flann)
    list_of_bboxes = []
    while img_true:
        list_of_bboxes.append(bbox)
        img_true, new_img, bbox = find_and_polly(new_img, key_points_query, description_query, query, sift, flann)

    return list_of_bboxes
#------------------------------------------------------------#